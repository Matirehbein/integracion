import { parseStringPromise } from 'xml2js';
import express from "express";
import cors from "cors";
import fetch from 'node-fetch';


// SDK de Mercado Pago
import { MercadoPagoConfig, Preference } from 'mercadopago';
// Agrega credenciales
const client = new MercadoPagoConfig({ accessToken: 'TEST-8712547894810563-052119-bc054d7d18e2807571a55842164a408c-1095493175' });


const app = express();
const port = 3000
function getCMFData(apiKey2='https://si3.bcentral.cl/SieteRestWS/SieteRestWS.ashx?user=123456789&pass=tuPassword&firstdate=YYYY-MM-DD&lastdate=YYYY-MM-DD&timeseries=codigodeserie&function=GetSeries') {
    const urls = {
      dolar: 'https://api.cmfchile.cl/api-sbifv3/recursos_api/dolar?apikey=${apiKey2}&formato=xml',
      uf: 'https://api.cmfchile.cl/api-sbifv3/recursos_api/uf?apikey=${apiKey2}&formato=xml',
      euro: 'https://api.cmfchile.cl/api-sbifv3/recursos_api/euro?apikey=${apiKey2}&formato=xml'
    };
    async function fetchCurrencyRates() {
    try {
      const [dolarResponse, ufResponse, euroResponse] = await Promise.all([
        fetch(urls.dolar),
        fetch(urls.uf),
        fetch(urls.euro)
      ]);
  
      const [dolarText, ufText, euroText] = await Promise.all([
        dolarResponse.text(),
        ufResponse.text(),
        euroResponse.text()
      ]);
  
      const [dolarJson, ufJson, euroJson] = await Promise.all([
        parseStringPromise(dolarText),
        parseStringPromise(ufText),
        parseStringPromise(euroText)
      ]);
  
      const dolarValue = parseFloat(dolarJson.IndicadoresFinancieros.Dolares[0].Dolar[0].Valor[0].replace(',', '.'));
      const ufValue = parseFloat(ufJson.IndicadoresFinancieros.UFs[0].UF[0].Valor[0].replace('.', '').replace(',', '.'));
      const euroValue = parseFloat(euroJson.IndicadoresFinancieros.Euros[0].Euro[0].Valor[0].replace(',', '.'));
  
      return {
        Dolar: dolarValue,
        UF: ufValue,
        EUR: euroValue
      };
  
    } catch (error) {
      console.error('Error fetching CMF data:', error);
      throw error;
    }
  } 
app.use(cors());
app.use(express.json());

app.get("/", (req,res) => {
    res.send("Soy el server :)");
});
app.get('/api/cmf', async (req, res) => {
    try {
      const data = await getCMFData();
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch data from CMF' });
    }
  }); 
  
app.post("/create_preference", async (req, res)=>{
    try{
        const body = {
            items: [
                {
                title: req.body.title,
                quantity: Number(req.body.quantity),
                unit_price: Number(req.body.price),
                currency_id: "CLP",
            },
        ],
        back_urls: {
            success: "https://www.youtube.com/@onthecode",
            failure: "https://www.youtube.com/@onthecode",
            pending: "https://www.youtube.com/@onthecode",
        },
        auto_return: "approved",
        };

        const preference = new Preference(client);
        const result = await preference.create({body});
        res.json({
            id: result.id,
        });
    } catch (error) { 
        console.log(error)
        res.status(500).json({
            error: "Error al crear la preferencia :("
        })
    }
});

app.listen(port, ()=>{
    console.log(`El servidor esta corriendo en el puerto ${port}`);
});
 }
