// Función para abrir el modal
function abrirModal() {
    document.getElementById("miModal").style.display = "block";
}

// Función para cerrar el modal
function cerrarModal() {
    document.getElementById("miModal").style.display = "none";
}

// Función para abrir el carrito de compras
function abrirCarrito() {
    document.getElementById("modalCarrito").style.display = "block";
}

// Función para cerrar el carrito de compras
function cerrarCarrito() {
    document.getElementById("modalCarrito").style.display = "none";
}

function finalizarCompra() {
    window.location.href = 'cliente/indexx.html';
}

